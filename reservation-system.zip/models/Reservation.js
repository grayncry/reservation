const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// 予約状態の定義
const STATUS = {
  AVAILABLE: '空き',
  PENDING: '調整中',
  RESERVED: '予約済み'
};

// 予約モデル
const ReservationSchema = new Schema({
  date: {
    type: Date,
    required: true
  },
  teacher: {
    type: Schema.Types.ObjectId,
    ref: 'Teacher',
    required: true
  },
  timeSlot: {
    type: Schema.Types.ObjectId,
    ref: 'TimeSlot',
    required: true
  },
  status: {
    type: String,
    enum: [STATUS.AVAILABLE, STATUS.PENDING, STATUS.RESERVED],
    default: STATUS.AVAILABLE
  },
  parentName: {
    type: String,
    default: ''
  },
  notes: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// 状態の定数をエクスポート
ReservationSchema.statics.STATUS = STATUS;

module.exports = mongoose.model('Reservation', ReservationSchema);
