# Render.comへのデプロイ手順書

## 1. プロジェクトのパッケージング

まず、予約管理システムのプロジェクトをZIPファイルにパッケージングします。

```bash
cd /home/ubuntu
zip -r reservation-system.zip reservation-system
```

このZIPファイルをダウンロードして、ローカルコンピュータに保存してください。

## 2. Render.comアカウントの作成

1. [Render.com](https://render.com/)にアクセスします
2. 「Sign Up」をクリックしてアカウントを作成します
3. メールアドレスとパスワードを入力して登録します

## 3. 新しいWebサービスの作成

1. Render.comのダッシュボードから「New +」→「Web Service」をクリックします
2. 「Upload Files」を選択します（GitHubリポジトリがある場合は「Build and deploy from a Git repository」を選択することもできます）
3. 先ほどダウンロードしたZIPファイル（reservation-system.zip）をアップロードします

## 4. サービスの設定

以下の設定を入力します：

- **Name**: reservation-system-demo（または好きな名前）
- **Region**: お住まいの地域に近いもの
- **Runtime**: Node
- **Build Command**: `npm install`
- **Start Command**: `node app.js`

## 5. 環境変数の設定

「Environment」タブをクリックし、以下の環境変数を追加します：

1. `MONGO_URI`: MongoDB Atlasの接続文字列
   ```
   mongodb+srv://username:password@cluster.mongodb.net/reservation-system?retryWrites=true&w=majority
   ```
   （MongoDB Atlasのアカウントを作成し、接続文字列を取得する必要があります）

2. `SESSION_SECRET`: セッション暗号化用のシークレットキー
   ```
   reservation-system-demo-secret-key
   ```

3. `PORT`: ポート番号
   ```
   10000
   ```

## 6. デプロイの実行

「Create Web Service」をクリックしてデプロイを開始します。デプロイには数分かかる場合があります。

## 7. デプロイ完了

デプロイが完了すると、以下のようなURLが表示されます：

```
https://reservation-system-demo.onrender.com
```

このURLをクリックすると、デプロイされた予約管理システムにアクセスできます。

## 8. 初期設定

1. ブラウザでシステムのURLにアクセスします
2. トップページの「スタッフの方」ボタンをクリックします
3. 「新規登録」リンクをクリックします
4. 管理者アカウントを作成します
5. ログイン後、先生と時間枠を設定します

## 9. 保護者向けURLの共有

保護者向けのURLは以下のようになります：

```
https://reservation-system-demo.onrender.com/parents
```

このURLを保護者に共有することで、予約状況を確認できるようになります。

## 注意事項

- Render.comの無料プランでは、一定時間使用されないとサービスがスリープ状態になります。最初のアクセス時に読み込みが遅くなる場合があります。
- MongoDB Atlasの無料プランには容量制限がありますが、通常の使用では十分です。
- 本番環境で使用する場合は、より強固なセキュリティ設定を行うことをお勧めします。
