const express = require('express');
const router = express.Router();
const moment = require('moment');
const Teacher = require('../models/Teacher');
const TimeSlot = require('../models/TimeSlot');
const Reservation = require('../models/Reservation');

// 保護者向けカレンダーの表示
router.get('/', async (req, res) => {
  try {
    // クエリパラメータから年月を取得（指定がなければ現在の年月）
    const year = req.query.year || moment().year();
    const month = req.query.month || moment().month() + 1;
    
    // 月の最初と最後の日を取得
    const startDate = moment(`${year}-${month}-01`);
    const endDate = moment(startDate).endOf('month');
    
    // 先生一覧を取得
    const teachers = await Teacher.find({ active: true }).sort({ name: 1 });
    
    // 時間枠一覧を取得
    const timeSlots = await TimeSlot.find({ active: true }).sort({ startTime: 1 });
    
    // 選択された月の予約情報を取得
    const reservations = await Reservation.find({
      date: {
        $gte: startDate.toDate(),
        $lte: endDate.toDate()
      }
    }).populate('teacher').populate('timeSlot');
    
    // カレンダーデータの作成
    const calendarData = [];
    
    // 月の日数分ループ
    for (let day = 1; day <= endDate.date(); day++) {
      const date = moment(`${year}-${month}-${day}`);
      const dayReservations = reservations.filter(r => 
        moment(r.date).date() === day
      );
      
      calendarData.push({
        date,
        dayOfWeek: date.format('ddd'),
        reservations: dayReservations
      });
    }
    
    res.render('parents/calendar', {
      title: '予約状況カレンダー',
      year,
      month,
      calendarData,
      teachers,
      timeSlots,
      moment,
      currentMonth: moment(`${year}-${month}-01`).format('YYYY年MM月'),
      prevMonth: moment(`${year}-${month}-01`).subtract(1, 'month'),
      nextMonth: moment(`${year}-${month}-01`).add(1, 'month'),
      STATUS: Reservation.STATUS
    });
  } catch (err) {
    console.error(err);
    res.render('parents/error', {
      title: 'エラー',
      message: 'カレンダーの読み込み中にエラーが発生しました'
    });
  }
});

module.exports = router;
