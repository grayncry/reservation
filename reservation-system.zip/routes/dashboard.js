const express = require('express');
const router = express.Router();
const moment = require('moment');
const Teacher = require('../models/Teacher');
const TimeSlot = require('../models/TimeSlot');
const Reservation = require('../models/Reservation');
const { ensureAuthenticated } = require('./staff');

// ダッシュボードの表示
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    // 現在の月を取得
    const currentMonth = moment().format('YYYY-MM');
    const nextMonth = moment().add(1, 'month').format('YYYY-MM');
    
    // 先生の数を取得
    const teacherCount = await Teacher.countDocuments({ active: true });
    
    // 時間枠の数を取得
    const timeSlotCount = await TimeSlot.countDocuments({ active: true });
    
    // 今月の予約数を取得
    const currentMonthReservations = await Reservation.countDocuments({
      date: {
        $gte: new Date(`${currentMonth}-01`),
        $lt: new Date(`${nextMonth}-01`)
      }
    });
    
    // 予約状態ごとの数を取得
    const availableCount = await Reservation.countDocuments({ status: Reservation.STATUS.AVAILABLE });
    const pendingCount = await Reservation.countDocuments({ status: Reservation.STATUS.PENDING });
    const reservedCount = await Reservation.countDocuments({ status: Reservation.STATUS.RESERVED });
    
    res.render('dashboard', {
      title: 'ダッシュボード',
      staff: req.session.staff,
      teacherCount,
      timeSlotCount,
      currentMonthReservations,
      availableCount,
      pendingCount,
      reservedCount,
      currentMonth: moment().format('YYYY年MM月')
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/staff/login');
  }
});

module.exports = router;
