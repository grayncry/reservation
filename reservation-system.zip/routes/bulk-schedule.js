const express = require('express');
const router = express.Router();
const moment = require('moment');
const Teacher = require('../models/Teacher');
const TimeSlot = require('../models/TimeSlot');
const Reservation = require('../models/Reservation');
const { ensureAuthenticated } = require('./staff');

// 一括スケジュール設定ページの表示
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    // クエリパラメータから先生IDを取得
    const teacherId = req.query.teacher;
    
    // 先生一覧を取得
    const teachers = await Teacher.find({ active: true }).sort({ name: 1 });
    
    // 時間枠一覧を取得
    const timeSlots = await TimeSlot.find({ active: true }).sort({ startTime: 1 });
    
    // 選択された先生
    let selectedTeacher = null;
    if (teacherId) {
      selectedTeacher = await Teacher.findById(teacherId);
    }
    
    // 現在の月と次の月を取得
    const currentMonth = moment();
    const nextMonth = moment().add(1, 'month');
    
    // 現在の月と次の月のカレンダーデータを作成
    const currentMonthDays = [];
    const nextMonthDays = [];
    
    // 現在の月の日数分ループ
    const currentMonthDaysInMonth = currentMonth.daysInMonth();
    for (let day = 1; day <= currentMonthDaysInMonth; day++) {
      const date = moment(`${currentMonth.format('YYYY-MM')}-${day.toString().padStart(2, '0')}`);
      currentMonthDays.push({
        date,
        dayOfWeek: date.format('ddd'),
        dayOfMonth: day
      });
    }
    
    // 次の月の日数分ループ
    const nextMonthDaysInMonth = nextMonth.daysInMonth();
    for (let day = 1; day <= nextMonthDaysInMonth; day++) {
      const date = moment(`${nextMonth.format('YYYY-MM')}-${day.toString().padStart(2, '0')}`);
      nextMonthDays.push({
        date,
        dayOfWeek: date.format('ddd'),
        dayOfMonth: day
      });
    }
    
    res.render('bulk-schedule/index', {
      title: '一括スケジュール設定',
      staff: req.session.staff,
      teachers,
      timeSlots,
      selectedTeacher,
      currentMonth,
      nextMonth,
      currentMonthDays,
      nextMonthDays,
      STATUS: Reservation.STATUS
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/dashboard');
  }
});

// 一括スケジュール設定処理
router.post('/apply', ensureAuthenticated, async (req, res) => {
  try {
    const { teacherId, timeSlotIds, dates, status } = req.body;
    
    // 入力検証
    if (!teacherId || !timeSlotIds || !dates || !status) {
      req.flash('error_msg', '必須項目が入力されていません');
      return res.redirect('/bulk-schedule');
    }
    
    // 先生の存在確認
    const teacher = await Teacher.findById(teacherId);
    if (!teacher) {
      req.flash('error_msg', '先生が見つかりませんでした');
      return res.redirect('/bulk-schedule');
    }
    
    // 時間枠の配列に変換
    const timeSlotIdsArray = Array.isArray(timeSlotIds) ? timeSlotIds : [timeSlotIds];
    
    // 日付の配列に変換
    const datesArray = Array.isArray(dates) ? dates : [dates];
    
    // 各日付と時間枠の組み合わせに対して予約を作成または更新
    let createdCount = 0;
    let updatedCount = 0;
    
    for (const date of datesArray) {
      for (const timeSlotId of timeSlotIdsArray) {
        // 既存の予約をチェック
        const existingReservation = await Reservation.findOne({
          date: new Date(date),
          teacher: teacherId,
          timeSlot: timeSlotId
        });
        
        if (existingReservation) {
          // 既存の予約を更新
          existingReservation.status = status;
          existingReservation.updatedAt = Date.now();
          await existingReservation.save();
          updatedCount++;
        } else {
          // 新規予約を作成
          const newReservation = new Reservation({
            date: new Date(date),
            teacher: teacherId,
            timeSlot: timeSlotId,
            status
          });
          
          await newReservation.save();
          createdCount++;
        }
      }
    }
    
    req.flash('success_msg', `${createdCount}件の予約を作成し、${updatedCount}件の予約を更新しました`);
    res.redirect(`/bulk-schedule?teacher=${teacherId}`);
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/bulk-schedule');
  }
});

module.exports = router;
