const express = require('express');
const router = express.Router();
const Teacher = require('../models/Teacher');
const { ensureAuthenticated } = require('./staff');

// 先生一覧の表示
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const teachers = await Teacher.find().sort({ name: 1 });
    
    res.render('teachers/index', {
      title: '先生管理',
      teachers,
      staff: req.session.staff
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/dashboard');
  }
});

// 先生登録ページの表示
router.get('/add', ensureAuthenticated, (req, res) => {
  res.render('teachers/add', {
    title: '先生の登録',
    staff: req.session.staff
  });
});

// 先生登録処理
router.post('/add', ensureAuthenticated, async (req, res) => {
  const { name, email } = req.body;
  
  try {
    // 入力検証
    if (!name || !email) {
      req.flash('error_msg', '全ての項目を入力してください');
      return res.redirect('/teachers/add');
    }
    
    // メールアドレスの重複チェック
    const existingTeacher = await Teacher.findOne({ email });
    
    if (existingTeacher) {
      req.flash('error_msg', 'このメールアドレスは既に登録されています');
      return res.redirect('/teachers/add');
    }
    
    // 新しい先生の作成
    const newTeacher = new Teacher({
      name,
      email
    });
    
    await newTeacher.save();
    
    req.flash('success_msg', '先生を登録しました');
    res.redirect('/teachers');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/teachers/add');
  }
});

// 先生編集ページの表示
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    
    if (!teacher) {
      req.flash('error_msg', '先生が見つかりませんでした');
      return res.redirect('/teachers');
    }
    
    res.render('teachers/edit', {
      title: '先生の編集',
      teacher,
      staff: req.session.staff
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/teachers');
  }
});

// 先生編集処理
router.put('/edit/:id', ensureAuthenticated, async (req, res) => {
  const { name, email, active } = req.body;
  
  try {
    // 入力検証
    if (!name || !email) {
      req.flash('error_msg', '全ての項目を入力してください');
      return res.redirect(`/teachers/edit/${req.params.id}`);
    }
    
    // 先生の更新
    await Teacher.findByIdAndUpdate(req.params.id, {
      name,
      email,
      active: active === 'on'
    });
    
    req.flash('success_msg', '先生情報を更新しました');
    res.redirect('/teachers');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect(`/teachers/edit/${req.params.id}`);
  }
});

// 先生削除処理
router.delete('/:id', ensureAuthenticated, async (req, res) => {
  try {
    await Teacher.findByIdAndDelete(req.params.id);
    
    req.flash('success_msg', '先生を削除しました');
    res.redirect('/teachers');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/teachers');
  }
});

module.exports = router;
