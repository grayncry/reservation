const express = require('express');
const router = express.Router();
const TimeSlot = require('../models/TimeSlot');
const { ensureAuthenticated } = require('./staff');

// 時間枠一覧の表示
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const timeSlots = await TimeSlot.find().sort({ startTime: 1 });
    
    res.render('timeslots/index', {
      title: '時間枠管理',
      timeSlots,
      staff: req.session.staff
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/dashboard');
  }
});

// 時間枠登録ページの表示
router.get('/add', ensureAuthenticated, (req, res) => {
  res.render('timeslots/add', {
    title: '時間枠の登録',
    staff: req.session.staff
  });
});

// 時間枠登録処理
router.post('/add', ensureAuthenticated, async (req, res) => {
  const { startTime, endTime } = req.body;
  
  try {
    // 入力検証
    if (!startTime || !endTime) {
      req.flash('error_msg', '全ての項目を入力してください');
      return res.redirect('/timeslots/add');
    }
    
    // 時間枠の重複チェック
    const existingTimeSlot = await TimeSlot.findOne({ startTime, endTime });
    
    if (existingTimeSlot) {
      req.flash('error_msg', 'この時間枠は既に登録されています');
      return res.redirect('/timeslots/add');
    }
    
    // 新しい時間枠の作成
    const newTimeSlot = new TimeSlot({
      startTime,
      endTime
    });
    
    await newTimeSlot.save();
    
    req.flash('success_msg', '時間枠を登録しました');
    res.redirect('/timeslots');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/timeslots/add');
  }
});

// 時間枠編集ページの表示
router.get('/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const timeSlot = await TimeSlot.findById(req.params.id);
    
    if (!timeSlot) {
      req.flash('error_msg', '時間枠が見つかりませんでした');
      return res.redirect('/timeslots');
    }
    
    res.render('timeslots/edit', {
      title: '時間枠の編集',
      timeSlot,
      staff: req.session.staff
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/timeslots');
  }
});

// 時間枠編集処理
router.put('/edit/:id', ensureAuthenticated, async (req, res) => {
  const { startTime, endTime, active } = req.body;
  
  try {
    // 入力検証
    if (!startTime || !endTime) {
      req.flash('error_msg', '全ての項目を入力してください');
      return res.redirect(`/timeslots/edit/${req.params.id}`);
    }
    
    // 時間枠の更新
    await TimeSlot.findByIdAndUpdate(req.params.id, {
      startTime,
      endTime,
      active: active === 'on'
    });
    
    req.flash('success_msg', '時間枠を更新しました');
    res.redirect('/timeslots');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect(`/timeslots/edit/${req.params.id}`);
  }
});

// 時間枠削除処理
router.delete('/:id', ensureAuthenticated, async (req, res) => {
  try {
    await TimeSlot.findByIdAndDelete(req.params.id);
    
    req.flash('success_msg', '時間枠を削除しました');
    res.redirect('/timeslots');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/timeslots');
  }
});

module.exports = router;
