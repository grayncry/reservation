const express = require('express');
const router = express.Router();

// ヘルプページの表示
router.get('/', (req, res) => {
  res.render('help', {
    title: 'ヘルプ・使い方ガイド',
    staff: req.session ? req.session.staff : null
  });
});

module.exports = router;
