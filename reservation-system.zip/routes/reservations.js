const express = require('express');
const router = express.Router();
const moment = require('moment');
const Teacher = require('../models/Teacher');
const TimeSlot = require('../models/TimeSlot');
const Reservation = require('../models/Reservation');
const { ensureAuthenticated } = require('./staff');

// 予約カレンダーの表示
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    // クエリパラメータから年月を取得（指定がなければ現在の年月）
    const year = req.query.year || moment().year();
    const month = req.query.month || moment().month() + 1;
    
    // 月の最初と最後の日を取得
    const startDate = moment(`${year}-${month}-01`);
    const endDate = moment(startDate).endOf('month');
    
    // 先生一覧を取得
    const teachers = await Teacher.find({ active: true }).sort({ name: 1 });
    
    // 時間枠一覧を取得
    const timeSlots = await TimeSlot.find({ active: true }).sort({ startTime: 1 });
    
    // 選択された月の予約情報を取得
    const reservations = await Reservation.find({
      date: {
        $gte: startDate.toDate(),
        $lte: endDate.toDate()
      }
    }).populate('teacher').populate('timeSlot');
    
    // カレンダーデータの作成
    const calendarData = [];
    
    // 月の日数分ループ
    for (let day = 1; day <= endDate.date(); day++) {
      const date = moment(`${year}-${month}-${day}`);
      const dayReservations = reservations.filter(r => 
        moment(r.date).date() === day
      );
      
      calendarData.push({
        date,
        dayOfWeek: date.format('ddd'),
        reservations: dayReservations
      });
    }
    
    res.render('reservations/calendar', {
      title: '予約カレンダー',
      staff: req.session.staff,
      year,
      month,
      calendarData,
      teachers,
      timeSlots,
      moment,
      currentMonth: moment(`${year}-${month}-01`).format('YYYY年MM月'),
      prevMonth: moment(`${year}-${month}-01`).subtract(1, 'month'),
      nextMonth: moment(`${year}-${month}-01`).add(1, 'month'),
      STATUS: Reservation.STATUS
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/dashboard');
  }
});

// 日別予約詳細の表示
router.get('/day/:date', ensureAuthenticated, async (req, res) => {
  try {
    const date = moment(req.params.date);
    
    if (!date.isValid()) {
      req.flash('error_msg', '無効な日付です');
      return res.redirect('/reservations');
    }
    
    // 先生一覧を取得
    const teachers = await Teacher.find({ active: true }).sort({ name: 1 });
    
    // 時間枠一覧を取得
    const timeSlots = await TimeSlot.find({ active: true }).sort({ startTime: 1 });
    
    // 選択された日の予約情報を取得
    const reservations = await Reservation.find({
      date: {
        $gte: date.startOf('day').toDate(),
        $lte: date.endOf('day').toDate()
      }
    }).populate('teacher').populate('timeSlot');
    
    res.render('reservations/day', {
      title: `${date.format('YYYY年MM月DD日')}の予約`,
      staff: req.session.staff,
      date,
      teachers,
      timeSlots,
      reservations,
      STATUS: Reservation.STATUS
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/reservations');
  }
});

// 予約の更新
router.post('/update', ensureAuthenticated, async (req, res) => {
  try {
    const { id, status, parentName, notes } = req.body;
    
    // 予約の更新
    await Reservation.findByIdAndUpdate(id, {
      status,
      parentName,
      notes,
      updatedAt: Date.now()
    });
    
    req.flash('success_msg', '予約を更新しました');
    
    // リダイレクト先を決定
    if (req.body.returnUrl) {
      res.redirect(req.body.returnUrl);
    } else {
      res.redirect('/reservations');
    }
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/reservations');
  }
});

// 新規予約の作成
router.post('/create', ensureAuthenticated, async (req, res) => {
  try {
    const { date, teacherId, timeSlotId, status, parentName, notes } = req.body;
    
    // 入力検証
    if (!date || !teacherId || !timeSlotId || !status) {
      req.flash('error_msg', '必須項目が入力されていません');
      return res.redirect(req.body.returnUrl || '/reservations');
    }
    
    // 既存の予約をチェック
    const existingReservation = await Reservation.findOne({
      date: new Date(date),
      teacher: teacherId,
      timeSlot: timeSlotId
    });
    
    if (existingReservation) {
      req.flash('error_msg', 'この時間枠には既に予約が存在します');
      return res.redirect(req.body.returnUrl || '/reservations');
    }
    
    // 新規予約の作成
    const newReservation = new Reservation({
      date: new Date(date),
      teacher: teacherId,
      timeSlot: timeSlotId,
      status,
      parentName: parentName || '',
      notes: notes || ''
    });
    
    await newReservation.save();
    
    req.flash('success_msg', '予約を作成しました');
    
    // リダイレクト先を決定
    if (req.body.returnUrl) {
      res.redirect(req.body.returnUrl);
    } else {
      res.redirect('/reservations');
    }
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/reservations');
  }
});

// 予約の削除
router.delete('/:id', ensureAuthenticated, async (req, res) => {
  try {
    await Reservation.findByIdAndDelete(req.params.id);
    
    req.flash('success_msg', '予約を削除しました');
    
    // リダイレクト先を決定
    if (req.body.returnUrl) {
      res.redirect(req.body.returnUrl);
    } else {
      res.redirect('/reservations');
    }
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/reservations');
  }
});

module.exports = router;
