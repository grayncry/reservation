const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const Staff = require('../models/Staff');

// ログインページの表示
router.get('/login', (req, res) => {
  res.render('staff/login', {
    title: 'スタッフログイン'
  });
});

// ログイン処理
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  
  try {
    // スタッフの検索
    const staff = await Staff.findOne({ email });
    
    if (!staff) {
      req.flash('error_msg', 'メールアドレスまたはパスワードが正しくありません');
      return res.redirect('/staff/login');
    }
    
    // パスワードの検証
    const isMatch = await staff.matchPassword(password);
    
    if (!isMatch) {
      req.flash('error_msg', 'メールアドレスまたはパスワードが正しくありません');
      return res.redirect('/staff/login');
    }
    
    // セッションにスタッフ情報を保存
    req.session.staff = {
      id: staff._id,
      name: staff.name,
      email: staff.email,
      isAdmin: staff.isAdmin
    };
    
    req.flash('success_msg', 'ログインしました');
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/staff/login');
  }
});

// ログアウト処理
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
    }
    res.redirect('/staff/login');
  });
});

// 認証ミドルウェア
const ensureAuthenticated = (req, res, next) => {
  if (req.session.staff) {
    return next();
  }
  req.flash('error_msg', 'ログインしてください');
  res.redirect('/staff/login');
};

// 管理者権限確認ミドルウェア
const ensureAdmin = (req, res, next) => {
  if (req.session.staff && req.session.staff.isAdmin) {
    return next();
  }
  req.flash('error_msg', '管理者権限が必要です');
  res.redirect('/dashboard');
};

// スタッフ登録ページ（管理者のみ）
router.get('/register', ensureAuthenticated, ensureAdmin, (req, res) => {
  res.render('staff/register', {
    title: 'スタッフ登録'
  });
});

// スタッフ登録処理
router.post('/register', ensureAuthenticated, ensureAdmin, async (req, res) => {
  const { name, email, password, password2, isAdmin } = req.body;
  
  try {
    // 入力検証
    if (!name || !email || !password || !password2) {
      req.flash('error_msg', '全ての項目を入力してください');
      return res.redirect('/staff/register');
    }
    
    if (password !== password2) {
      req.flash('error_msg', 'パスワードが一致しません');
      return res.redirect('/staff/register');
    }
    
    // メールアドレスの重複チェック
    const existingStaff = await Staff.findOne({ email });
    
    if (existingStaff) {
      req.flash('error_msg', 'このメールアドレスは既に登録されています');
      return res.redirect('/staff/register');
    }
    
    // 新しいスタッフの作成
    const newStaff = new Staff({
      name,
      email,
      password,
      isAdmin: isAdmin === 'on'
    });
    
    await newStaff.save();
    
    req.flash('success_msg', 'スタッフを登録しました');
    res.redirect('/staff/list');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/staff/register');
  }
});

// スタッフ一覧（管理者のみ）
router.get('/list', ensureAuthenticated, ensureAdmin, async (req, res) => {
  try {
    const staffList = await Staff.find().sort({ createdAt: -1 });
    
    res.render('staff/list', {
      title: 'スタッフ一覧',
      staffList
    });
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/dashboard');
  }
});

// スタッフ削除（管理者のみ）
router.delete('/:id', ensureAuthenticated, ensureAdmin, async (req, res) => {
  try {
    await Staff.findByIdAndDelete(req.params.id);
    
    req.flash('success_msg', 'スタッフを削除しました');
    res.redirect('/staff/list');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'エラーが発生しました');
    res.redirect('/staff/list');
  }
});

module.exports = {
  router,
  ensureAuthenticated,
  ensureAdmin
};
