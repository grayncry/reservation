// ヘルプ情報とツールチップを追加するJavaScript
$(function () {
  // ツールチップの初期化
  $('[data-toggle="tooltip"]').tooltip();
  
  // カレンダーの日付セルにホバーエフェクトを追加
  $('.calendar-day').hover(
    function() {
      $(this).addClass('calendar-day-hover');
    },
    function() {
      $(this).removeClass('calendar-day-hover');
    }
  );
  
  // フォームの送信前に確認ダイアログを表示
  $('.confirm-submit').on('submit', function(e) {
    if (!confirm('この操作を実行してもよろしいですか？')) {
      e.preventDefault();
    }
  });
  
  // 一括スケジュール設定の選択日数カウンター
  function updateSelectedDatesCounter() {
    const count = $('.date-item.selected').length;
    $('#selected-dates-counter').text(count + '日選択中');
  }
  
  // 日付選択時のイベントハンドラー
  $(document).on('click', '.date-item', function() {
    setTimeout(updateSelectedDatesCounter, 100);
  });
  
  // ページ読み込み時にカウンターを更新
  updateSelectedDatesCounter();
  
  // モバイルデバイスでのナビゲーションの改善
  if (window.innerWidth < 768) {
    $('.navbar-nav .nav-item').on('click', function() {
      $('.navbar-collapse').collapse('hide');
    });
  }
  
  // フラッシュメッセージの自動非表示
  setTimeout(function() {
    $('.alert-dismissible').fadeOut('slow');
  }, 5000);
  
  // 印刷ボタンの機能
  $('.print-button').on('click', function() {
    window.print();
  });
});
