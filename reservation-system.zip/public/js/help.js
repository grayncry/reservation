// ヘルプページの内容
document.addEventListener('DOMContentLoaded', function() {
  // ヘルプアコーディオンの動作
  const accordionItems = document.querySelectorAll('.help-accordion-item');
  
  accordionItems.forEach(item => {
    const header = item.querySelector('.help-accordion-header');
    const content = item.querySelector('.help-accordion-content');
    
    header.addEventListener('click', function() {
      // アクティブなアイテムを切り替える
      const isActive = item.classList.contains('active');
      
      // すべてのアイテムを非アクティブにする
      accordionItems.forEach(i => {
        i.classList.remove('active');
        i.querySelector('.help-accordion-content').style.maxHeight = null;
      });
      
      // クリックされたアイテムをアクティブにする（すでにアクティブだった場合を除く）
      if (!isActive) {
        item.classList.add('active');
        content.style.maxHeight = content.scrollHeight + 'px';
      }
    });
  });
  
  // 検索機能
  const searchInput = document.getElementById('help-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase();
      
      accordionItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        if (text.includes(searchTerm)) {
          item.style.display = '';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }
  
  // 印刷ボタン
  const printButton = document.getElementById('print-help');
  if (printButton) {
    printButton.addEventListener('click', function() {
      window.print();
    });
  }
  
  // すべて展開/折りたたむボタン
  const expandAllButton = document.getElementById('expand-all');
  const collapseAllButton = document.getElementById('collapse-all');
  
  if (expandAllButton) {
    expandAllButton.addEventListener('click', function() {
      accordionItems.forEach(item => {
        item.classList.add('active');
        const content = item.querySelector('.help-accordion-content');
        content.style.maxHeight = content.scrollHeight + 'px';
      });
    });
  }
  
  if (collapseAllButton) {
    collapseAllButton.addEventListener('click', function() {
      accordionItems.forEach(item => {
        item.classList.remove('active');
        const content = item.querySelector('.help-accordion-content');
        content.style.maxHeight = null;
      });
    });
  }
});
