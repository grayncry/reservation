# 予約管理システム デプロイ手順書

## 1. 前提条件

- Node.js (v14以上)
- npm (v6以上)
- MongoDB (v4以上)またはMongoDB Atlas接続情報

## 2. システムのインストール

### 2.1 ソースコードの取得

```bash
git clone https://github.com/your-organization/reservation-system.git
cd reservation-system
```

または、提供されたZIPファイルを解凍してください。

### 2.2 依存パッケージのインストール

```bash
npm install
```

### 2.3 環境設定

`.env`ファイルを作成し、以下の内容を設定します：

```
MONGO_URI=mongodb://localhost:27017/reservation-system
# または MongoDB Atlas接続文字列
# MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/reservation-system

PORT=3000
SESSION_SECRET=your-secret-key
```

## 3. データベースの初期設定

### 3.1 初期データの作成

初期管理者アカウントを作成するには、以下のコマンドを実行します：

```bash
node setup-admin.js
```

このスクリプトは、以下の管理者アカウントを作成します：
- メールアドレス: admin@example.com
- パスワード: admin123

**重要**: 初期設定後、必ずパスワードを変更してください。

## 4. システムの起動

### 4.1 開発環境での起動

```bash
npm run dev
```

### 4.2 本番環境での起動

```bash
npm start
```

または、PM2などのプロセスマネージャーを使用することを推奨します：

```bash
npm install -g pm2
pm2 start app.js --name "reservation-system"
```

## 5. システムへのアクセス

- スタッフ向けインターフェース: http://your-server:3000/staff/login
- 保護者向けカレンダー: http://your-server:3000/parents

## 6. バックアップ手順

### 6.1 データベースのバックアップ

```bash
mongodump --uri="mongodb://localhost:27017/reservation-system" --out=./backup
```

### 6.2 バックアップの復元

```bash
mongorestore --uri="mongodb://localhost:27017/reservation-system" ./backup/reservation-system
```

## 7. トラブルシューティング

### 7.1 接続エラー

MongoDB接続エラーが発生した場合：
- MongoDB サービスが実行中であることを確認
- 接続文字列が正しいことを確認
- ファイアウォール設定を確認

### 7.2 アプリケーションエラー

アプリケーションが起動しない場合：
- ログファイルを確認
- Node.jsとnpmのバージョンを確認
- 依存パッケージが正しくインストールされていることを確認

## 8. 更新手順

システムを更新する場合：

```bash
git pull
npm install
npm run build
pm2 restart reservation-system
```

## 9. サポート

問題が解決しない場合は、以下の連絡先までお問い合わせください：
- メール: support@example.com
- 電話: 03-1234-5678
