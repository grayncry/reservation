// テスト用のデータベース接続スクリプト
const mongoose = require('mongoose');
const Staff = require('./models/Staff');
const Teacher = require('./models/Teacher');
const TimeSlot = require('./models/TimeSlot');
const Reservation = require('./models/Reservation');

// データベース接続
const connectDB = async () => {
  try {
    const conn = await mongoose.connect('mongodb://localhost:27017/reservation-system-test', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    return conn;
  } catch (err) {
    console.error(`Error: ${err.message}`);
    process.exit(1);
  }
};

// テストデータの作成
const createTestData = async () => {
  try {
    // コレクションのクリア
    await Staff.deleteMany({});
    await Teacher.deleteMany({});
    await TimeSlot.deleteMany({});
    await Reservation.deleteMany({});
    
    console.log('既存のデータをクリアしました');
    
    // 管理者スタッフの作成
    const adminStaff = new Staff({
      name: '管理者',
      email: 'admin@example.com',
      password: 'password123',
      isAdmin: true
    });
    
    await adminStaff.save();
    console.log('管理者スタッフを作成しました');
    
    // 通常スタッフの作成
    const normalStaff = new Staff({
      name: '一般スタッフ',
      email: 'staff@example.com',
      password: 'password123',
      isAdmin: false
    });
    
    await normalStaff.save();
    console.log('一般スタッフを作成しました');
    
    // 先生の作成
    const teachers = [
      { name: '山田先生', email: 'yamada@example.com' },
      { name: '佐藤先生', email: 'sato@example.com' },
      { name: '鈴木先生', email: 'suzuki@example.com' }
    ];
    
    const createdTeachers = await Teacher.insertMany(teachers);
    console.log('先生データを作成しました');
    
    // 時間枠の作成
    const timeSlots = [
      { startTime: '09:00', endTime: '10:30' },
      { startTime: '11:00', endTime: '12:30' },
      { startTime: '13:30', endTime: '15:00' },
      { startTime: '15:30', endTime: '17:00' }
    ];
    
    const createdTimeSlots = await TimeSlot.insertMany(timeSlots);
    console.log('時間枠データを作成しました');
    
    // 現在の月と次の月の日付を取得
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();
    
    // 予約データの作成（現在の月のサンプルデータ）
    const reservations = [];
    
    // 各先生と時間枠の組み合わせでサンプル予約を作成
    for (let day = 1; day <= 28; day += 7) {
      for (let teacherIndex = 0; teacherIndex < createdTeachers.length; teacherIndex++) {
        for (let timeSlotIndex = 0; timeSlotIndex < createdTimeSlots.length; timeSlotIndex++) {
          // 予約状態をランダムに設定
          const statusOptions = [
            Reservation.STATUS.AVAILABLE,
            Reservation.STATUS.PENDING,
            Reservation.STATUS.RESERVED
          ];
          const randomStatus = statusOptions[Math.floor(Math.random() * statusOptions.length)];
          
          // 予約日を設定
          const reservationDate = new Date(currentYear, currentMonth, day);
          
          // 予約データを作成
          reservations.push({
            date: reservationDate,
            teacher: createdTeachers[teacherIndex]._id,
            timeSlot: createdTimeSlots[timeSlotIndex]._id,
            status: randomStatus,
            parentName: randomStatus === Reservation.STATUS.RESERVED ? '保護者サンプル' : '',
            notes: randomStatus !== Reservation.STATUS.AVAILABLE ? 'テスト予約' : ''
          });
        }
      }
    }
    
    await Reservation.insertMany(reservations);
    console.log('予約サンプルデータを作成しました');
    
    console.log('テストデータの作成が完了しました');
  } catch (err) {
    console.error('テストデータの作成中にエラーが発生しました:', err);
  }
};

// メイン実行関数
const runTest = async () => {
  const conn = await connectDB();
  await createTestData();
  
  // 接続を閉じる
  await mongoose.connection.close();
  console.log('データベース接続を閉じました');
};

// スクリプト実行
runTest();
