// メインアプリケーションファイルの更新
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const session = require('express-session');
const flash = require('connect-flash');
const connectDB = require('./config/db');

// データベース接続
connectDB();

const app = express();

// EJSテンプレートエンジンの設定
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ミドルウェア
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

// セッション設定
app.use(session({
  secret: 'reservation-system-secret',
  resave: true,
  saveUninitialized: true
}));

// フラッシュメッセージ
app.use(flash());

// グローバル変数
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  next();
});

// ルート
app.get('/', (req, res) => {
  res.render('index', {
    title: '予約管理システム'
  });
});

// スタッフルーター
const { router: staffRouter } = require('./routes/staff');
app.use('/staff', staffRouter);

// 先生ルーター
const teachersRouter = require('./routes/teachers');
app.use('/teachers', teachersRouter);

// 時間枠ルーター
const timeslotsRouter = require('./routes/timeslots');
app.use('/timeslots', timeslotsRouter);

// ダッシュボードルーター
const dashboardRouter = require('./routes/dashboard');
app.use('/dashboard', dashboardRouter);

// 予約ルーター
const reservationsRouter = require('./routes/reservations');
app.use('/reservations', reservationsRouter);

// 一括スケジュールルーター
const bulkScheduleRouter = require('./routes/bulk-schedule');
app.use('/bulk-schedule', bulkScheduleRouter);

// 保護者ルーター
const parentsRouter = require('./routes/parents');
app.use('/parents', parentsRouter);

// ヘルプルーター
const helpRouter = require('./routes/help');
app.use('/help', helpRouter);

const PORT = process.env.PORT || 3000;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
