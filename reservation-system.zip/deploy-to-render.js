// Render.com用のデプロイスクリプト
const fs = require('fs');
const path = require('path');

// package.jsonにenginesフィールドを追加
const packageJsonPath = path.join(__dirname, 'package.json');
const packageJson = require(packageJsonPath);

// Node.jsとnpmのバージョンを指定
packageJson.engines = {
  "node": ">=14.0.0",
  "npm": ">=6.0.0"
};

// startスクリプトを追加
if (!packageJson.scripts) {
  packageJson.scripts = {};
}
packageJson.scripts.start = "node app.js";

// package.jsonを更新
fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));

console.log('Render.com用のデプロイ準備が完了しました。');
console.log('以下の手順でデプロイしてください：');
console.log('1. Render.comにアカウントを作成');
console.log('2. 「New Web Service」を選択');
console.log('3. GitHubリポジトリを連携するか、このコードをアップロード');
console.log('4. 環境変数を設定（render.jsonを参照）');
console.log('5. 「Create Web Service」をクリック');
